package com.scalebank.wharehouseservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WharehouseserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(WharehouseserviceApplication.class, args);
	}

}
