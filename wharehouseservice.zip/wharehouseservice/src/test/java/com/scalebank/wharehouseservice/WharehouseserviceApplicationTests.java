package com.scalebank.wharehouseservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WharehouseserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
